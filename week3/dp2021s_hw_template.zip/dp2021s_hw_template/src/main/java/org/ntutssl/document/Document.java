package org.ntutssl.document;

public interface Document { 
    public String getText();
 }
